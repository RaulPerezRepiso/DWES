<?php
$tabla = new CGrid($cabecera, $fill, ["class" => "tabla1"]);
echo $tabla->dibujate();
